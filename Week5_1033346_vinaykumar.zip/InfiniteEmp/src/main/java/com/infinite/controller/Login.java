package com.infinite.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author vinaykumarpa
 *
 */
@Controller
public class Login {
	private final JdbcTemplate jdbcTemplate;
	public Login(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}//used jdbc template
	@GetMapping("/login")
	public String showLoginForm() {
		return "login";
	}
	@PostMapping("/login")
	public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password,
			Model model) {
		boolean isAuthenticated = authenticateUser(email, password);
		if (isAuthenticated) {
			return "redirect:/welcome";//return to welcome.jsp
		} else {
			model.addAttribute("error", "Invalid email or password");
			return "login";//else return to login.jsp
		}
	}
	private boolean authenticateUser(String email, String password) {
		return false;
	}
}
