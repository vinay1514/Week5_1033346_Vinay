package com.infinite.controller;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author vinaykumarpa
 *
 */
@Controller
@RequestMapping("/registration")
public class Registration {
//using jdbc template
	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;
	private PlatformTransactionManager transactionManager;

	public Registration(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@GetMapping
	public String showRegistrationForm() {
		return "registration";
	}

	@PostMapping
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}
//query updation
	public String registerUser(@RequestParam("fullname") String fullname, @RequestParam("email") String email,
			@RequestParam("password") String password, @RequestParam("birthday") String birthday,
			@RequestParam("gender") String gender, @RequestParam("profession") String profession,
			@RequestParam(value = "married", required = false) boolean married) {

		String sql = "insert into users (fullname, email, password, birthday, gender, profession, married) "
				+ "values (?, ?, ?, ?, ?, ?, ?)";

		jdbcTemplate.update(sql, fullname, email, password, birthday, gender, profession, married ? "Yes" : "No");

		return "redirect:/success";//return tos success.jsp page
	}
}
